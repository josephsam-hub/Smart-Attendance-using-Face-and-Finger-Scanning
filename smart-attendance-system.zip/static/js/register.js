const video = document.getElementById("video");
navigator.mediaDevices.getUserMedia({ video: true })
  .then(stream => video.srcObject = stream);

function startCapture() {
    const name = document.getElementById("nameInput").value.trim();
    if (!name) return alert("Enter a name!");
    const canvas = document.createElement("canvas");
    const ctx = canvas.getContext("2d");
    let count = 0;
    let interval = setInterval(() => {
        if (count >= 25) {
            clearInterval(interval);
            document.getElementById("status").textContent = "Done!";
            return;
        }
        canvas.width = video.videoWidth;
        canvas.height = video.videoHeight;
        ctx.drawImage(video, 0, 0);
        const img = canvas.toDataURL("image/jpeg");
        fetch('/upload_face', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({name: name, image: img, count: count})
        }).then(res => res.json()).then(data => console.log(data.message));
        count++;
        document.getElementById("status").textContent = `Capturing ${count}/25`;
    }, 300);
}
