const video = document.getElementById("video");
navigator.mediaDevices.getUserMedia({ video: true })
  .then(stream => video.srcObject = stream);

function recognize() {
    const canvas = document.createElement("canvas");
    const ctx = canvas.getContext("2d");
    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;
    ctx.drawImage(video, 0, 0);
    const img = canvas.toDataURL("image/jpeg");
    fetch('/recognize_face', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({image: img})
    }).then(res => res.json()).then(data => {
        document.getElementById("output").textContent = 
            data.status === "recognized" ? `✅ Welcome ${data.name}` : "❌ Face not recognized";
    });
}
