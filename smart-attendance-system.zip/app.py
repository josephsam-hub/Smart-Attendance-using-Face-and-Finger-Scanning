from flask import Flask, render_template, request, redirect, session, jsonify
from deepface import DeepFace
import os
import base64
import cv2
import numpy as np
import pandas as pd
from datetime import datetime

app = Flask(__name__)
app.secret_key = 'admin123'
UPLOAD_FOLDER = 'uploads'
ATTENDANCE_FOLDER = 'attendance'
ADMIN_USERNAME = 'admin'
ADMIN_PASSWORD = '1234'

@app.route('/', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        if request.form['username'] == ADMIN_USERNAME and request.form['password'] == ADMIN_PASSWORD:
            session['admin'] = True
            return redirect('/dashboard')
        else:
            return render_template('login.html', error='Invalid credentials')
    return render_template('login.html')

@app.route('/dashboard')
def dashboard():
    if not session.get('admin'):
        return redirect('/')
    return render_template('dashboard.html')

@app.route('/register')
def register():
    if not session.get('admin'):
        return redirect('/')
    return render_template('register.html')

@app.route('/upload_face', methods=['POST'])
def upload_face():
    data = request.json
    name = data.get("name")
    image_data = data.get("image")
    count = data.get("count")

    if not name or not image_data:
        return {"status": "error", "message": "Missing data"}, 400

    student_dir = os.path.join(UPLOAD_FOLDER, name)
    os.makedirs(student_dir, exist_ok=True)

    image_data = image_data.split(',')[1]
    image_bytes = base64.b64decode(image_data)
    img_path = os.path.join(student_dir, f"{name}_{count}.jpg")
    
    with open(img_path, 'wb') as f:
        f.write(image_bytes)

    return {"status": "success", "message": f"Image {count} saved"}

@app.route('/attendance')
def attendance():
    if not session.get('admin'):
        return redirect('/')
    return render_template('attendance.html')

@app.route('/recognize_face', methods=['POST'])
def recognize_face():
    image_data = request.json.get('image')
    image_data = image_data.split(',')[1]
    image_bytes = base64.b64decode(image_data)
    nparr = np.frombuffer(image_bytes, np.uint8)
    frame = cv2.imdecode(nparr, cv2.IMREAD_COLOR)

    for name in os.listdir(UPLOAD_FOLDER):
        user_dir = os.path.join(UPLOAD_FOLDER, name)
        for img_name in os.listdir(user_dir):
            try:
                img_path = os.path.join(user_dir, img_name)
                result = DeepFace.verify(frame, img_path, enforce_detection=False)
                if result['verified']:
                    date_str = datetime.now().strftime("%Y-%m-%d")
                    time_str = datetime.now().strftime("%H:%M:%S")
                    filename = os.path.join(ATTENDANCE_FOLDER, f"attendance_{date_str}.csv")
                    if os.path.exists(filename):
                        df = pd.read_csv(filename)
                        if name not in df['Name'].values:
                            df = pd.concat([df, pd.DataFrame([[name, date_str, time_str]], columns=["Name", "Date", "Time"])])
                            df.to_csv(filename, index=False)
                    else:
                        df = pd.DataFrame([[name, date_str, time_str]], columns=["Name", "Date", "Time"])
                        df.to_csv(filename, index=False)
                    return {"status": "recognized", "name": name}
            except:
                continue
    return {"status": "unrecognized"}

@app.route('/logout')
def logout():
    session.pop('admin', None)
    return redirect('/')

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)
